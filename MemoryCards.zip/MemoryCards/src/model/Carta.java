/*package model;

import model.Tipo;

public class Carta {
    private int valor;
    private Tipo tipo;

    public int getValor() {
        return this.valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Tipo getTipo() {
        return this.tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public Carta(int valor, Tipo tipo) {
        this.valor = valor;
        this.tipo = tipo;
    }
}   */
