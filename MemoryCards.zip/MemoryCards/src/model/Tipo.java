/*package model;

public enum Tipo {
    OROS,
    BASTOS,
    COPAS,
    ESPADAS;
    

    private Tipo(String string2, int n2) {
    }
}
*/